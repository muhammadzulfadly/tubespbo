-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 19, 2023 at 06:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubespbo`
--

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

CREATE TABLE `agency` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `agency`
--

INSERT INTO `agency` (`username`, `password`) VALUES
('agency', 'agency');

-- --------------------------------------------------------

--
-- Table structure for table `kontrak`
--

CREATE TABLE `kontrak` (
  `id` varchar(10) NOT NULL,
  `idproperty` varchar(10) NOT NULL,
  `namapenyewa` varchar(20) NOT NULL,
  `namaagency` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `jaminan` int(100) NOT NULL,
  `waktupenyewaan` date NOT NULL,
  `waktupengambilan` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kontrak`
--

INSERT INTO `kontrak` (`id`, `idproperty`, `namapenyewa`, `namaagency`, `tanggal`, `jaminan`, `waktupenyewaan`, `waktupengambilan`, `status`) VALUES
('K001', 'P001', 'Penyewa', 'Agency', '2023-06-17', 1000000, '2023-06-17', '2023-06-30', 'tersedia'),
('K0011', 'P002', 'Penyewa2', 'agency', '2023-06-17', 1500000, '2023-06-19', '2023-06-20', 'tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`username`, `password`) VALUES
('pegawai', 'pegawai');

-- --------------------------------------------------------

--
-- Table structure for table `penyewa`
--

CREATE TABLE `penyewa` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penyewa`
--

INSERT INTO `penyewa` (`username`, `password`) VALUES
('penyewa', 'penyewa');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `idproperty` int(10) NOT NULL,
  `jumlahproperty` int(20) NOT NULL,
  `statusproperty` tinyint(1) NOT NULL,
  `kondisiproperty` varchar(20) NOT NULL,
  `hargaproperty` int(50) NOT NULL,
  `namaproperty` varchar(100) NOT NULL,
  `tanggalsewa` varchar(20) NOT NULL,
  `durasisewa` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`idproperty`, `jumlahproperty`, `statusproperty`, `kondisiproperty`, `hargaproperty`, `namaproperty`, `tanggalsewa`, `durasisewa`) VALUES
(1111, 10, 1, 'tersedia', 1000000, 'Acara Ulang Tahun', '10-01-23', '5'),
(2222, 15, 1, 'tersedia', 15000000, 'Acara Seminar', '', ''),
(3333, 20, 1, 'tersedia', 20000000, 'Pesta Pernikahan', '', ''),
(4444, 20, 1, 'tersedia', 25000000, 'Acara Aqiqah', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agency`
--
ALTER TABLE `agency`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `kontrak`
--
ALTER TABLE `kontrak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `penyewa`
--
ALTER TABLE `penyewa`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`idproperty`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
