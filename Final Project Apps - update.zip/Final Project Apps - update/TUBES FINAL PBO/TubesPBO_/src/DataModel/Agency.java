/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataModel;

/**
 *
 * @author Asus
 */
import java.util.List;
import java.util.Scanner;

public class Agency {
    
    private String Username;
    private String Password;
    private boolean registered;
    
    public Agency(){}
    public Agency(String Username, String password){
        this.Username = Username;
        this.Password = Password;
        this.registered = false;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public boolean isRegistered() {
        return registered;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setRegistered(boolean registered) {
        this.registered = registered;
    }
    
//    public boolean register(Scanner scanner, Pegawai pegawai){
//        if(!registered){
//            System.out.println("Username: ");
//            String inputUsername = scanner.nextLine();
//            System.out.println("Password: ");
//            String inputPassword = scanner.nextLine();
//            
//            
//        }
//    }
}
