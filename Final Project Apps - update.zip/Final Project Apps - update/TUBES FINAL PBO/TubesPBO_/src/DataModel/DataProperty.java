/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataModel;

/**
 *
 * @author Asus
 */
public class DataProperty {
    private int idProperty;
    private int jumlahProperty;
    private boolean statusProperty;
    private String kondisiProperty;
    private int hargaProperty;
    private String namaProperty;
    private String tanggalSewa;
    private String durasiSewa;
    
    public DataProperty(){
        
    }

    public int getIdProperty() {
        return idProperty;
    }

    public void setIdProperty(int idProperty) {
        this.idProperty = idProperty;
    }

    public int getJumlahProperty() {
        return jumlahProperty;
    }

    public void setJumlahProperty(int jumlahProperty) {
        this.jumlahProperty = jumlahProperty;
    }

    public boolean isStatusProperty() {
        return statusProperty;
    }

    public void setStatusProperty(boolean statusProperty) {
        this.statusProperty = statusProperty;
    }

    public String getKondisiProperty() {
        return kondisiProperty;
    }

    public void setKondisiProperty(String kondisiProperty) {
        this.kondisiProperty = kondisiProperty;
    }

    public int getHargaProperty() {
        return hargaProperty;
    }

    public void setHargaProperty(int hargaProperty) {
        this.hargaProperty = hargaProperty;
    }

    public String getNamaProperty() {
        return namaProperty;
    }

    public void setNamaProperty(String namaProperty) {
        this.namaProperty = namaProperty;
    }

    public String getTanggalSewa() {
        return tanggalSewa;
    }

    public void setTanggalSewa(String tanggalSewa) {
        this.tanggalSewa = tanggalSewa;
    }

    public String getDurasiSewa() {
        return durasiSewa;
    }

    public void setDurasiSewa(String durasiSewa) {
        this.durasiSewa = durasiSewa;
    }
    
    
            
}
