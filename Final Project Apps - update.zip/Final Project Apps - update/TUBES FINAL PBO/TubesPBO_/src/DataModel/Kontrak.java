/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataModel;

/**
 *
 * @author Asus
 */
public class Kontrak {
    private String idKontrak;
    private String username;
    private String idProperty;
    private String namaPenyewa;
    private String namaAgency;
    private String tanggalKontrak;
    private int jaminan;
    private String watkuPenyewaan;
    private String WaktuPengambilan;
    private String status;
    
    public Kontrak(){
        
    }

    public String getIdKontrak() {
        return idKontrak;
    }

    public void setIdKontrak(String idKontrak) {
        this.idKontrak = idKontrak;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIdProperty() {
        return idProperty;
    }

    public void setIdProperty(String idProperty) {
        this.idProperty = idProperty;
    }

    public String getNamaPenyewa() {
        return namaPenyewa;
    }

    public void setNamaPenyewa(String namaPenyewa) {
        this.namaPenyewa = namaPenyewa;
    }

    public String getNamaAgency() {
        return namaAgency;
    }

    public void setNamaAgency(String namaAgency) {
        this.namaAgency = namaAgency;
    }

    public String getTanggalKontrak() {
        return tanggalKontrak;
    }

    public void setTanggalKontrak(String tanggalKontrak) {
        this.tanggalKontrak = tanggalKontrak;
    }

    public int getJaminan() {
        return jaminan;
    }

    public void setJaminan(int jaminan) {
        this.jaminan = jaminan;
    }

    public String getWatkuPenyewaan() {
        return watkuPenyewaan;
    }

    public void setWatkuPenyewaan(String watkuPenyewaan) {
        this.watkuPenyewaan = watkuPenyewaan;
    }

    public String getWaktuPengambilan() {
        return WaktuPengambilan;
    }

    public void setWaktuPengambilan(String WaktuPengambilan) {
        this.WaktuPengambilan = WaktuPengambilan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
