package DAO;

import DataBase.DBConnection;
import DataModel.Agency;
import DataModel.DataProperty;
import DataModel.Kontrak;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AgencyDAO implements iAgencyDAO {
    
    List<Agency> listAgen;
    List<DataProperty> listProperty;
    
    
   @Override
   public void insertPropertyPenyewa(DataProperty property){
       String sql = "INSERT INTO SewaProperty (namaProperty, idProperty, jumlahProperty, hargaProperty kondisiProperty, durasiSewa, tanggalSewa) "
               + "VALUES (?, ?, ?, ?)";
       try (
           PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)){
           statement.setString(1, property.getNamaProperty());
           statement.setInt(2, property.getIdProperty());
           statement.setInt(3, property.getJumlahProperty());
           statement.setInt(4, property.getHargaProperty());
           statement.setString(5, property.getKondisiProperty());
           statement.setString(6, property.getDurasiSewa());
           statement.setString(7, property.getTanggalSewa());
           
           statement.executeUpdate();
       } catch (SQLException e) {
           Logger.getLogger(AgencyDAO.class.getName()).log(Level.SEVERE, null, e);
       }
   }
   
   @Override
   public List<Agency> getAllAgency(){
       listAgen = new ArrayList<>();
       Statement statement;
       String sql = "select * from agency";
       try {
           statement = DBConnection.getConnection().createStatement();
           
           ResultSet result = statement.executeQuery(sql);
           
           while (result.next()) {
               Agency agen = new Agency();
               agen.setUsername(result.getString(1));
               agen.setPassword(result.getString(2));
               agen.setRegistered(true);
               listAgen.add(agen);
           }
           statement.close();
           result.close();
           
           return listAgen;
       } catch (SQLException ex) {
           Logger.getLogger(AgencyDAO.class.getName()).log(Level.SEVERE, null, ex);
           return null;
       }
   }

    @Override
    public List<DataProperty> getDataProperty() {
          listProperty = new ArrayList<>();
       Statement statement;
       String sql = "SELECT * FROM property";
       try{
           statement = DBConnection.getConnection().createStatement();
           
            try (ResultSet result = statement.executeQuery(sql)) {

                while (result.next()) {
                        
                   DataProperty property = new DataProperty();
                        
                    property.setNamaProperty(result.getString(6));
                    property.setIdProperty(result.getInt(1));
                    property.setJumlahProperty(result.getInt(2));
                    property.setKondisiProperty(result.getString(4));
                    property.setStatusProperty(result.getBoolean(3));
                    property.setHargaProperty(result.getInt(5));
                    property.setTanggalSewa(result.getString(7));
                    property.setDurasiSewa(result.getString(8));
                       
                    listProperty.add(property);

                }
                statement.close();
            }
            return listProperty;
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
    }

    @Override
    public List<Kontrak> getAllKontrakAgency() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void insertKontrak(Kontrak kontrak) {
        String sql = "INSERT INTO kontrak (id, idproperty, namapenyewa, namaagency, tanggal, jaminan, waktupenyewaan, waktupengambilan, status) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
       try (
           PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)){
           statement.setString(1, kontrak.getIdKontrak());
           statement.setString(2, kontrak.getIdProperty());
           statement.setString(3, kontrak.getNamaPenyewa());
           statement.setString(4, kontrak.getNamaAgency());
           statement.setString(5, kontrak.getTanggalKontrak());
           statement.setInt(6, kontrak.getJaminan());
           statement.setString(7, kontrak.getWatkuPenyewaan());
           statement.setString(8, kontrak.getWaktuPengambilan());
           statement.setString(9, kontrak.getStatus());
           
           
           statement.executeUpdate();
       } catch (SQLException e) {
           Logger.getLogger(AgencyDAO.class.getName()).log(Level.SEVERE, null, e);
       }
    }

   
}
