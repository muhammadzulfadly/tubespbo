/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

/**
 *
 * @author Asus
 */

import java.util.List;
import DataModel.*;

public interface iPegawaiDAO {
    
    
    public void insertPropertyPenyewa(DataProperty property);
    public void insertPenyewa(Penyewa penyewa);
    public void tambahProperty(String namaProperty, int id_property, int jumlah, String keterangan);
    public void updateProperty (DataProperty property);
    public void delete(String namaProperty);
    
    public List<DataProperty> getProperty(String namaProperty);
    
    public void deleteProperty();
    public List<DataProperty> getProperty();
    public List<Pegawai> getAllPegawai();
    public List<Kontrak> getAllKontrak();
    public void update();
    public void delete(int idProperty);
    
}
