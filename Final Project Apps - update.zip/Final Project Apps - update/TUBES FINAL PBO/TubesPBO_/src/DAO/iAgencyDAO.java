/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import DataModel.Agency;
import DataModel.DataProperty;
import java.util.List;
import DataModel.*;
/**
 *
 * @author Asus
 */
public interface iAgencyDAO {
    public void insertPropertyPenyewa(DataProperty property);
    public void insertKontrak(Kontrak kontrak);
    public List<DataProperty> getDataProperty();
    public List<Agency> getAllAgency();
    public List<Kontrak> getAllKontrakAgency();
    
 
}
