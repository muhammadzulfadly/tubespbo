
package DAO;

import DataBase.DBConnection;
import DataModel.Agency;
import DataModel.DataProperty;
import DataModel.Kontrak;
import DataModel.Pegawai;
import DataModel.Penyewa;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PenyewaDAO implements iPenyewaDAO{
    List<Agency> listAgen;
    List<Pegawai> listPegawai;
    List<Penyewa> listPenyewa;
    List<String> listKodeAgensi;
    List<DataProperty> listProperty;
            
    @Override
    public List<DataProperty> getProperty(String namaProperty, int idProperty, int jumlahProperty, String keterangan, double harga ){
        listProperty = new ArrayList<>();
        Statement statement;
        String sql = "SELECT * FROM property WHERE namaProperty LIKE '%" + namaProperty +"%' AND jumlahProperty < " + jumlahProperty + " AND 'hargaProperty (Rupiah)' < " + harga;
            try {
                statement = DBConnection.getConnection().createStatement();

                try (ResultSet result = statement.executeQuery(sql)) {

                    while (result.next()) { 
                        
                    DataProperty property = new DataProperty();
                        
                    property.setNamaProperty(result.getString(1));
                    property.setIdProperty(result.getInt(2));
                    property.setJumlahProperty(result.getInt(3));
                    property.setKondisiProperty(result.getString(4));
                       
                    listProperty.add(property);

                }
                statement.close();
            }
            return listProperty;
        } catch (SQLException e) {
            Logger.getLogger(PenyewaDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
    }
    
    @Override
    
    public void KontrakProperty(Kontrak property) {
        String sql = "INSERT INTO property (idKontrak, username, idProperty, namaPenyewa, namaAgency, tanggalKontrak, jaminan, waktuPenyewaan, waktuPengambilan, status) "
                +"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
         try (
            PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)) {
            statement.setInt(1, Integer.parseInt(property.getIdKontrak()));
            statement.setString(2, property.getUsername());
            statement.setString(3, property.getIdProperty());
            statement.setString(4, property.getNamaPenyewa());
            statement.setString(5, property.getNamaAgency());
            statement.setString(6, property.getTanggalKontrak());
            statement.setInt(7, property.getJaminan());
            statement.setString(8, property.getWatkuPenyewaan());
            statement.setString(9, property.getWaktuPengambilan());
            statement.setString(10, property.getStatus());
            
            statement.executeUpdate();
            
            } catch (SQLException e) {
                Logger.getLogger(PenyewaDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public List<Penyewa> getAllPenyewa() {
        listPenyewa = new ArrayList<>();
        Statement statement;
        String sql = "SELECT * FROM penyewa";
            try {
                statement = DBConnection.getConnection().createStatement();

                try (ResultSet result = statement.executeQuery(sql)) {

                    while (result.next()) { 
                        
                    Penyewa penyewa = new Penyewa();
                        
                    penyewa.setUsername(result.getString(1));
                    penyewa.setPassword(result.getString(2));
                    
                       
                    listPenyewa.add(penyewa);

                }
                statement.close();
            }
            return listPenyewa;
        } catch (SQLException e) {
            Logger.getLogger(PenyewaDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
    }
    
}
