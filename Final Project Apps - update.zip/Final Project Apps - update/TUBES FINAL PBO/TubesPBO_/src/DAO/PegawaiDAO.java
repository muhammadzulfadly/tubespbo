package DAO;

import DataBase.DBConnection;
import DataModel.Agency;
import DataModel.DataProperty;
import DataModel.Kontrak;
import DataModel.Pegawai;
import DataModel.Penyewa;
import GUI.TampilanPegawai;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class PegawaiDAO implements iPegawaiDAO {
    List<Kontrak> listKontrak;
    List<Agency> listAgen;
    List<Pegawai> listPegawai;
    List<String> listKodeAgensi;
    List<DataProperty> listProperty;
    
    @Override
   public void insertPropertyPenyewa(DataProperty property){
       String sql = "INSERT INTO property (statusproperty, namaProperty, idProperty, jumlahProperty, hargaProperty, kondisiProperty, durasiSewa, tanggalSewa) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
       try (
           PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)){
           statement.setString(2, property.getNamaProperty());
           statement.setInt(3, property.getIdProperty());
           statement.setInt(4, property.getJumlahProperty());
           statement.setInt(5, property.getHargaProperty());
           statement.setString(6, property.getKondisiProperty());
           statement.setString(7, property.getDurasiSewa());
           statement.setString(8, property.getTanggalSewa());
           statement.setBoolean(1, property.isStatusProperty());
           
           
           statement.executeUpdate();
       } catch (SQLException e) {
           Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
       }
   }
   
   @Override
   public void tambahProperty(String namaProperty, int id_property, int jumlah, String keterangan){
       String sql = "INSERT INTO List Property (namaProperty, idProperty, jumlah, keterangan) " 
               + "VALUES (?, ?, ?, ?)";
         try (
            PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)) {
            statement.setString(1, namaProperty);
            statement.setInt(2, id_property);
            statement.setInt(3, jumlah);
            statement.setString(4, keterangan);
            
            statement.executeUpdate();
            
            } catch (SQLException e) {
                Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
   
   @Override
   public void updateProperty (DataProperty property){
       TampilanPegawai TP = new TampilanPegawai();
        //String sql = "UPDATE property set namaproperty = '" + TP.getTextPropertyPegawai().getText()+ "', jumlahproperty='" + TP.getTextJumlahPropertyPegawai().getText() + "' , kondisiproperty='" + TP.getTextKeteranganPropertyPegawai1().getText()+ "', hargaproperty='" + TP.getTextHargaProperty().getText() + "'";
        String sql = "UPDATE property SET namaproperty =?, jumlahproperty =?, kondisiproperty=?, hargaproperty=? WHERE idproperty =?"; 
        try{
                 PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql);
                 
                 statement.setInt(5, property.getIdProperty());
                 statement.setString(1, property.getNamaProperty());
                 statement.setInt(2, property.getJumlahProperty());
                 statement.setString(3, property.getKondisiProperty());
                 statement.setInt(4, property.getHargaProperty());
                 JOptionPane.showMessageDialog(null, "Update Berhasil");
                 statement.execute();
                 statement.close();
             } catch ( SQLException e) {
                     //Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
                     JOptionPane.showMessageDialog(TP, e.getMessage());
         }
     }
   
   @Override
   public void delete(String namaProperty) {
        String sql = "DELETE FROM rumah WHERE namaProperty=?";
        PreparedStatement statement;
        try {
            statement = DBConnection.getConnection().prepareStatement(sql);
            statement.setString(1, namaProperty);
            statement.executeUpdate();
            
            statement.close();
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
   
   @Override
   public List<DataProperty> getProperty(String namaProperty){
       listProperty = new ArrayList<>();
       Statement statement;
       String sql = "SELECT * FROM property WHERE namaProperty= '"+ namaProperty+"'";
       try{
           statement = DBConnection.getConnection().createStatement();
           
            try (ResultSet result = statement.executeQuery(sql)) {

                while (result.next()) {
                        
                   DataProperty property = new DataProperty();
                        
                    property.setNamaProperty(result.getString(6));
                    property.setIdProperty(result.getInt(1));
                    property.setJumlahProperty(result.getInt(2));
                    property.setKondisiProperty(result.getString(4));
                    property.setStatusProperty(result.getBoolean(3));
                    property.setHargaProperty(result.getInt(5));
                    property.setTanggalSewa(result.getString(7));
                    property.setDurasiSewa(result.getString(8));
                    
                    listProperty.add(property);

                }
                statement.close();
            }
            return listProperty;
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
    }

    @Override
    public void deleteProperty() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DataProperty> getProperty() {
        listProperty = new ArrayList<>();
       Statement statement;
       String sql = "SELECT * FROM property";
       try{
           statement = DBConnection.getConnection().createStatement();
           
            try (ResultSet result = statement.executeQuery(sql)) {

                while (result.next()) {
                        
                   DataProperty property = new DataProperty();
                        
                    property.setNamaProperty(result.getString(6));
                    property.setIdProperty(result.getInt(1));
                    property.setJumlahProperty(result.getInt(2));
                    property.setKondisiProperty(result.getString(4));
                    property.setStatusProperty(result.getBoolean(3));
                    property.setHargaProperty(result.getInt(5));
                    property.setTanggalSewa(result.getString(7));
                    property.setDurasiSewa(result.getString(8));
                       
                    listProperty.add(property);

                }
                statement.close();
            }
            return listProperty;
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
            return null;
        }
    }

    @Override
    public List<Pegawai> getAllPegawai() {
        listPegawai = new ArrayList<>();
       Statement statement;
       String sql = "select * from pegawai";
       try {
           statement = DBConnection.getConnection().createStatement();
           
           ResultSet result = statement.executeQuery(sql);
           
           while (result.next()) {
               Pegawai pegawai = new Pegawai();
               pegawai.setUsername(result.getString(1));
               pegawai.setPassword(result.getString(2));
               
               listPegawai.add(pegawai);
           }
           statement.close();
           result.close();
           
           return listPegawai;
       } catch (SQLException ex) {
           Logger.getLogger(AgencyDAO.class.getName()).log(Level.SEVERE, null, ex);
           return null;
       }
    }

    @Override
    public List<Kontrak> getAllKontrak() {
listKontrak = new ArrayList<>();
       Statement statement;
       String sql = "select * from kontrak";
       try {
           statement = DBConnection.getConnection().createStatement();
           
           ResultSet result = statement.executeQuery(sql);
           
           while (result.next()) {
               Kontrak kontrak = new Kontrak();
               kontrak.setIdKontrak(result.getString(1));
               kontrak.setIdProperty(result.getString(2));
               kontrak.setNamaPenyewa(result.getString(3));
               kontrak.setNamaAgency(result.getString(4));
               kontrak.setTanggalKontrak(result.getString(5));
               kontrak.setJaminan(result.getInt(6));
               kontrak.setWatkuPenyewaan(result.getString(7));
               kontrak.setWaktuPengambilan(result.getString(8));
               kontrak.setStatus(result.getString(9));
               
               listKontrak.add(kontrak);
           }
           statement.close();
           result.close();
           
           return listKontrak;
       } catch (SQLException ex) {
           Logger.getLogger(AgencyDAO.class.getName()).log(Level.SEVERE, null, ex);
           return null;
       }
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int idProperty) {
        String sql = "DELETE FROM property WHERE idproperty=" + idProperty;
        PreparedStatement statement;
        try {
            statement = DBConnection.getConnection().prepareStatement(sql);
            statement.executeUpdate();
            
            statement.close();
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void insertPenyewa(Penyewa penyewa) {
        String sql = "INSERT INTO penyewa (username, password) "
                + "VALUES (?, ?)";
        try (
                PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql)) {
            statement.setString(1, penyewa.getUsername());
            statement.setString(2, penyewa.getPassword());
            
        

            statement.executeUpdate();
        } catch (SQLException e) {
            Logger.getLogger(PegawaiDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}