/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import DataModel.DataProperty;
import DataModel.Kontrak;
import DataModel.Penyewa;
import java.util.List;

/**
 *
 * @author Asus
 */
public interface iPenyewaDAO {
    public List<DataProperty> getProperty(String namaProperty, int idProperty, int jumlahProperty, String keterangan, double harga );
    public void KontrakProperty(Kontrak property);
    public List<Penyewa> getAllPenyewa();
}
