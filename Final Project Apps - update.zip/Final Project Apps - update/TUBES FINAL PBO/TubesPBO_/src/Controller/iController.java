/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Controller;

/**
 *
 * @author Asus
 */
public interface iController {
    
    public void showDefault();
    public void Register();
    public void PenyewaLogin();
    public void PegawaiLogin();
    public void AgencyLogin();
    public void PenyewaRegister();
    public void PenyewaKeTampilan();
    public void AgencyKeTampilan();
    public void PegawaiKeTampilan();
    public void TabelPegawai();
    public void TabelKontrak();
    public void Logout();
    public void BackKontrakAgency();
    public void AgencyKeKontrak();
    public void IsiTabel();
    public void cari();
    public void CariAgency();
    public void updateTabel();
    public void insertKontrak();
    public void insertTabelPegawai();
    public void Delete(int row);
    
}
