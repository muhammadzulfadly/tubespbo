/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.AgencyDAO;
import DAO.PegawaiDAO;
import DAO.PenyewaDAO;
import DAO.iAgencyDAO;
import DAO.iPegawaiDAO;
import DAO.iPenyewaDAO;
import DataModel.Agency;
import DataModel.DataProperty;
import DataModel.Kontrak;
import DataModel.Pegawai;
import DataModel.Penyewa;
import DataModel.TableDataKontrak;
import DataModel.TableDataProperty;
import DataModel.TableDataPropertyAgency;
import GUI.AgencyLogin;
import GUI.Login;
import GUI.PegawaiLogin;
import GUI.PenyewaLogin;
import GUI.PenyewaRegister;
import GUI.TampilanAgency;
import GUI.TampilanKontrak;
import GUI.TampilanPegawai;
import GUI.TampilanPenyewaa;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class Controller implements iController {

    private Login FrameLogin;
    private PenyewaRegister FrameRegister;
    private PenyewaLogin FramePenyewaLogin;
    private PegawaiLogin FramePegawaiLogin;
    private AgencyLogin FrameAgencyLogin;
    private TampilanPenyewaa FrameTampilanPenyewa;
    private TampilanAgency FrameTampilanAgency;
    private Login FrameLogout;
    private TampilanKontrak FrameTampilanKontrak;
    private TampilanPegawai FrameTampilanPegawai;
    private List<Kontrak> listKontrak;
    private List<DataProperty> PropertyList;
    private List<Penyewa> PenyewaList;
    private List<Pegawai> PegawaiList;
    private List<Agency> AgencyList;
    private iAgencyDAO AgencyDao;
    private iPegawaiDAO PegawaiDao;
    private iPenyewaDAO PenyewaDao;

    public Controller() {
        this.FrameLogin = new Login();
        this.FrameRegister = new PenyewaRegister();
        this.FramePenyewaLogin = new PenyewaLogin();
        this.FramePegawaiLogin = new PegawaiLogin();
        this.FrameAgencyLogin = new AgencyLogin();
        this.FrameTampilanPenyewa = new TampilanPenyewaa();
        this.FrameTampilanAgency = new TampilanAgency();
        this.FrameTampilanKontrak = new TampilanKontrak();
        this.FrameTampilanPegawai = new TampilanPegawai();
        this.FrameLogout = new Login();
        this.AgencyDao = new AgencyDAO();
        this.PegawaiDao = new PegawaiDAO();
        this.PenyewaDao = new PenyewaDAO();
        this.listKontrak = PegawaiDao.getAllKontrak();
        this.PenyewaList = PenyewaDao.getAllPenyewa();
        this.AgencyList = AgencyDao.getAllAgency();
        this.PegawaiList = PegawaiDao.getAllPegawai();
        this.PropertyList = PegawaiDao.getProperty();
        this.FrameTampilanPenyewa.setController(this);
        this.FramePenyewaLogin.setController(this);
    }

    @Override
    public void showDefault() {
        this.FrameLogin.setVisible(true);
        this.FrameRegister.setController(this);
        this.FrameLogin.setController(this);
    }

    @Override
    public void Register() {
        this.FrameLogin.setVisible(false);
        this.FrameRegister.setVisible(true);

    }

    @Override
    public void PenyewaLogin() {
        this.FrameLogin.setVisible(false);
        this.FramePenyewaLogin.setController(this);
        this.FramePenyewaLogin.setVisible(true);

    }

    @Override
    public void PegawaiLogin() {
        this.FrameLogin.setVisible(false);
        this.FramePegawaiLogin.setController(this);
        this.FramePegawaiLogin.setVisible(true);
    }

    @Override
    public void AgencyLogin() {
        this.FrameLogin.setVisible(false);
        this.FrameAgencyLogin.setController(this);
        this.FrameAgencyLogin.setVisible(true);
    }

    @Override
    public void PenyewaRegister() {
    }

    @Override
    public void PenyewaKeTampilan() {
        //this.FrameTampilanPenyewa.setController(this);
        String username = this.FramePenyewaLogin.getUsernameField().getText();
        String password = this.FramePenyewaLogin.getPasswordField().getText();
        boolean found = false;
        for (int i = 0; i < PenyewaList.size(); i++) {
            if (username.equals(PenyewaList.get(i).getUsername()) && password.equals(PenyewaList.get(i).getPassword())) {
                found = true;
                break;
            }
        }
        if (found) {
            this.FramePenyewaLogin.setVisible(false);

            this.FrameTampilanPenyewa.setVisible(true);
            JOptionPane.showMessageDialog(FramePenyewaLogin, "Login Berhasil");
        } 
    }

    @Override
    public void IsiTabel() {

        PropertyList = PegawaiDao.getProperty();
        TableDataProperty tbl = new TableDataProperty(PropertyList);
        this.FrameTampilanPenyewa.getTabelProperti().setModel(tbl);
        this.FrameTampilanAgency.getTabelAgency().setModel(tbl);

    }

    @Override
    public void cari() {
        PropertyList = PegawaiDao.getProperty(this.FrameTampilanPenyewa.getTextCariProperty().getText());
        TableDataProperty tbl = new TableDataProperty(PropertyList);
        this.FrameTampilanPenyewa.getTabelProperti().setModel(tbl);
    }

    @Override
    public void CariAgency() {
        PropertyList = PegawaiDao.getProperty(this.FrameTampilanAgency.getTextKetersediaanBarang().getText());
        TableDataPropertyAgency tbl = new TableDataPropertyAgency(PropertyList);
        this.FrameTampilanAgency.getTabelAgency().setModel(tbl);
    }

    @Override
    public void AgencyKeTampilan() {
        this.FrameTampilanAgency.setController(this);
        String username = this.FrameAgencyLogin.getUsernameField().getText();
        String password = this.FrameAgencyLogin.getPasswordField().getText();
        boolean found = false;
        System.out.println(AgencyList.get(0).getUsername());
        for (int i = 0; i < AgencyList.size(); i++) {
            if (username.equals(AgencyList.get(i).getUsername()) && password.equals(AgencyList.get(i).getPassword())) {
                found = true;
                break;
            }
        }
        if (found) {
            this.FrameAgencyLogin.setVisible(false);

            this.FrameTampilanAgency.setVisible(true);
            JOptionPane.showMessageDialog(FrameAgencyLogin, "Login Berhasil");
        }
    }

    @Override
    public void Logout() {
        this.FrameTampilanPenyewa.setVisible(false);
        this.FrameLogout.setController(this);
        this.FrameLogout.setVisible(true);
    }

    @Override
    public void AgencyKeKontrak() {
        this.FrameTampilanAgency.setVisible(false);
        this.FrameTampilanKontrak.setController(this);
        this.FrameTampilanKontrak.setVisible(true);
    }

    @Override
    public void insertKontrak() {
        Kontrak kontrak = new Kontrak();

        kontrak.setIdKontrak("K00" + listKontrak.size() + 1);
        kontrak.setIdProperty(this.FrameTampilanKontrak.getTextIdProperty().getText());
        kontrak.setJaminan(Integer.parseInt(this.FrameTampilanKontrak.getTextJaminan().getText()));
        kontrak.setNamaAgency(this.FrameAgencyLogin.getUsernameField().getText());
        kontrak.setNamaPenyewa(this.FrameTampilanKontrak.getTextNamaPenyewa4().getText());
        kontrak.setTanggalKontrak(this.FrameTampilanKontrak.getTextTanggalKontrak().getText());
        kontrak.setWatkuPenyewaan(this.FrameTampilanKontrak.getTextWaktuPenyewaan().getText());
        kontrak.setWaktuPengambilan(this.FrameTampilanKontrak.getTextWaktuPengambilan1().getText());
        kontrak.setStatus("tersedia");
        
        listKontrak = PegawaiDao.getAllKontrak();
        TableDataKontrak tbl = new TableDataKontrak(listKontrak);
        this.FrameTampilanKontrak.getjTable1().setModel(tbl);

        AgencyDao.insertKontrak(kontrak);
        listKontrak.add(kontrak);

    }

    @Override
    public void PegawaiKeTampilan() {
        this.FrameTampilanPegawai.setController(this);
        String username = this.FramePegawaiLogin.getUsernameField().getText();
        String password = this.FramePegawaiLogin.getPasswordField().getText();
        boolean found = false;
        for (int i = 0; i < PegawaiList.size(); i++) {
            if (username.equals(PegawaiList.get(i).getUsername()) && password.equals(PegawaiList.get(i).getPassword())) {
                found = true;
                break;
            }
        }
        if (found) {
            this.FramePegawaiLogin.setVisible(false);

            this.FrameTampilanPegawai.setVisible(true);
            JOptionPane.showMessageDialog(FramePegawaiLogin, "Login Berhasil");
        } 
    }

    @Override
    public void TabelPegawai() {
        PropertyList = PegawaiDao.getProperty();
        TableDataProperty tbl = new TableDataProperty(PropertyList);
        this.FrameTampilanPegawai.getTablePegawai().setModel(tbl);
    }

    @Override
    public void insertTabelPegawai() {
        
    }

    public void Delete(int row) {
        
    }

    @Override
    public void BackKontrakAgency() {
        this.FrameTampilanKontrak.setVisible(false);
        this.FrameTampilanAgency.setController(this);
        this.FrameTampilanAgency.setVisible(true);
    }

    @Override
    public void TabelKontrak() {
        listKontrak = PegawaiDao.getAllKontrak();
        TableDataKontrak tbl = new TableDataKontrak(listKontrak);
        this.FrameTampilanKontrak.getjTable1().setModel(tbl);

    }

    @Override
    public void updateTabel() {
        DataProperty property = new DataProperty();

        property.setNamaProperty(this.FrameTampilanPegawai.getTextPropertyPegawai().getText());
        property.setIdProperty(Integer.parseInt(this.FrameTampilanPegawai.getTextIdpropertyPegawai().getText()));
        property.setJumlahProperty(Integer.parseInt(this.FrameTampilanPegawai.getTextJumlahPropertyPegawai().getText()));
        property.setKondisiProperty(this.FrameTampilanPegawai.getTextKeteranganPropertyPegawai1().getText());
        property.setHargaProperty(Integer.parseInt(this.FrameTampilanPegawai.getTextHargaProperty().getText()));
        property.setDurasiSewa("");
        property.setStatusProperty(true);
        property.setTanggalSewa("");

        PegawaiDao.updateProperty(property);
       
        TabelPegawai();
    }

}
