/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package MealPlanJavaGUI;

import Application.Application;
import View.*;
import Controller.Controller;



/**
 *
 * @author alift
 */
public class MealPlanJavaGUI {

    public static void main(String[] args) {
//        Application app = new Application();
//        app.menu();
        Controller userController = new Controller();
//        LoginPanelq log = new LoginPanel(userController);
//        log.setVisible(true);
//        CreateRecipePanel c = new CreateRecipePanel(userController);
    }
}
