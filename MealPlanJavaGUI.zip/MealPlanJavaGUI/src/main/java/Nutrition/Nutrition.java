/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Nutrition;

/**
 *
 * @author alift
 */
public abstract class Nutrition {
    protected int calories;
    protected int protein;
    protected int carbs;
    protected int fat;

    public abstract void setNutrition();

    public abstract void displayNutrition();
}
