/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataModel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Asus
 */
public class TabelDataPropertyPegawai extends AbstractTableModel {
       List<DataProperty> listProperty;
    
    public TabelDataPropertyPegawai(List<DataProperty> list){
        this.listProperty = list;
    }
    
    @Override
    public int getRowCount() {
        return listProperty.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0: return listProperty.get(rowIndex).getNamaProperty();
            case 1: return listProperty.get(rowIndex).getIdProperty();
            case 2: return listProperty.get(rowIndex).getJumlahProperty();
            case 3: return listProperty.get(rowIndex).getKondisiProperty();
            case 4: return listProperty.get(rowIndex).getHargaProperty();
            default: return null;
        }
    }
    
    public List<Object> getColumnValues(int columnIndex) {
        List<Object> columnValues = new ArrayList<>();

        for (int row = 0; row < 4; row++) {
            Object value = getValueAt(row, columnIndex);
            columnValues.add(value);
        }

        return columnValues;
    }
    
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "Nama Property";
            case 1: return "ID Property";
            case 2: return "Jumlah";
            case 3: return "Keterangan";
            case 4: return "Harga";
            
            default: return null;
        }
    }
}
