/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataModel;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Asus
 */
public class TableDataKontrak extends AbstractTableModel{
     List<Kontrak> listKontrak;
    
    public TableDataKontrak(List<Kontrak> list){
        this.listKontrak = list;
    }
    
    @Override
    public int getRowCount() {
        return listKontrak.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0: return listKontrak.get(rowIndex).getIdKontrak();
            case 1: return listKontrak.get(rowIndex).getIdProperty();
            case 2: return listKontrak.get(rowIndex).getJaminan();
            case 3: return listKontrak.get(rowIndex).getNamaPenyewa();
            case 4: return listKontrak.get(rowIndex).getTanggalKontrak();
            case 5: return listKontrak.get(rowIndex).getWatkuPenyewaan();
            case 6: return listKontrak.get(rowIndex).getWaktuPengambilan();
            default: return null;
        }
    }
    
    public List<Object> getColumnValues(int columnIndex) {
        List<Object> columnValues = new ArrayList<>();

        for (int row = 0; row < 4; row++) {
            Object value = getValueAt(row, columnIndex);
            columnValues.add(value);
        }

        return columnValues;
    }
    
    public String getColumnName(int column) {
        switch (column) {
            case 0: return "ID Kontrak";
            case 1: return "ID Property";
            case 2: return "Jaminan";
            case 3: return "Nama Penyewa";
            case 4: return "Tanggal Kontrak";
            case 5: return "Waktu Penyewaan";
            case 6: return "Waktu Pengambilan";
            
            default: return null;
        }
    }
}
